<?php $__env->startSection('content'); ?>



    <section style="background: url(<?php echo e(url('/')); ?>/assets/images/<?php echo e($settings[0]->background); ?>) no-repeat center center; background-size: cover;">
        <div class="row">
            <div class="container" style="min-height: 300px;">
                <div class="home-section">
                    <h1><?php echo e($settings[0]->home_text1); ?></h1>
                    <p><?php echo e($settings[0]->home_text2); ?></p>
                    <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(url('/')); ?>/services/<?php echo e($category->slug); ?>">
                            <button class="btn btn-home"><?php echo e($category->name); ?></button>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
            </div>
        </div>
    </section>

    <section class="go-section">
        <div class="row">
            <div class="container">
                <h2 class="text-center">All Available Services</h2>
                <hr>
                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-md-4 text-center services">
                        <div class="services-div">
                            <h1><?php echo e($category->name); ?></h1>
                            <p>Services</p>
                            <a href="<?php echo e(url('/')); ?>/services/<?php echo e($category->slug); ?>">
                                <button class="btn btn-views">View</button>
                            </a>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>