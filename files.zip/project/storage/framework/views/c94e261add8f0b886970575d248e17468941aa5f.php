<?php $__env->startSection('content'); ?>
<section class="go-slider">
<div id="bootstrap-touch-slider" class="carousel bs-slider fade  control-round indicators-line" data-ride="carousel" data-pause="hover" data-interval="5000" >

    <!-- Indicators -->
    <ol class="carousel-indicators">
        <?php for($i = 0; $i < count($sliders); $i++): ?>
            <?php if($i == 0): ?>
                <li data-target="#bootstrap-touch-slider" data-slide-to="<?php echo e($i); ?>" class="active"></li>
            <?php else: ?>
                <li data-target="#bootstrap-touch-slider" data-slide-to="<?php echo e($i); ?>"></li>
            <?php endif; ?>
        <?php endfor; ?>
    </ol>

    <!-- Wrapper For Slides -->
    <div class="carousel-inner" role="listbox">

        <?php for($i = 0; $i < count($sliders); $i++): ?>
            <?php if($i == 0): ?>
                <!-- Third Slide -->
                    <div class="item active">

                        <!-- Slide Background -->
                        <img src="<?php echo e(url('/')); ?>/assets/images/sliders/<?php echo e($sliders[$i]->image); ?>" alt="Bootstrap Touch Slider"  class="slide-image"/>
                        <div class="bs-slider-overlay"></div>

                        <div class="container">
                            <div class="row">
                                <!-- Slide Text Layer -->
                                <div class="slide-text <?php echo e($sliders[$i]->text_position); ?>">

                                    <h1 data-animation="animated fadeInDown"><?php echo e($sliders[$i]->title); ?></h1>
                                    <p data-animation="animated fadeInUp"><?php echo e($sliders[$i]->text); ?></p>

                                </div>

                            </div>
                        </div>
                    </div>
                    <!-- End of Slide -->
            <?php else: ?>
            <!-- Second Slide -->
                <div class="item">

                    <!-- Slide Background -->
                    <img src="<?php echo e(url('/')); ?>/assets/images/sliders/<?php echo e($sliders[$i]->image); ?>" alt="Bootstrap Touch Slider"  class="slide-image"/>
                    <div class="bs-slider-overlay"></div>
                    <!-- Slide Text Layer -->
                    <div class="slide-text <?php echo e($sliders[$i]->text_position); ?>">
                        <h1 data-animation="animated fadeInDown"><?php echo e($sliders[$i]->title); ?></h1>
                        <p data-animation="animated fadeInUp"><?php echo e($sliders[$i]->text); ?></p>
                    </div>
                </div>
                <!-- End of Slide -->
            <?php endif; ?>
    <?php endfor; ?>


    </div><!-- End of Wrapper For Slides -->

        <!-- Left Control -->
        <a class="left carousel-control" href="#bootstrap-touch-slider" role="button" data-slide="prev">
            <span class="fa fa-angle-left" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>

        <!-- Right Control -->
        <a class="right carousel-control" href="#bootstrap-touch-slider" role="button" data-slide="next">
            <span class="fa fa-angle-right" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>

    </div> <!-- End  bootstrap-touch-slider Slider -->

</section>

<section class="go-services">
    <div class="row">
        <div class="container">
            <div class="col-md-6 col-md-offset-3">
                <div class="section-title">
                    <h2><?php echo e($languages->service_title); ?></h2>
                    <p><?php echo e($languages->service_text); ?></p>
                </div>
            </div>
            <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-xs-12 col-md-4">
                    <div class="service-list text-center wow fadeInUp">
                        <img src="<?php echo e(url('/assets/images/service')); ?>/<?php echo e($service->icon); ?>" alt="">
                        <h3><?php echo e($service->title); ?></h3>
                        <p><?php echo e($service->text); ?></p>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section>

<section class="go-pricing">
    <div class="section-padding">
        <div class="container">
            <div class="row">
                <div class="col-md-6 col-md-offset-3">
                    <div class="section-title">
                        <h2><?php echo e($languages->pricing_title); ?></h2>
                        <p><?php echo e($languages->pricing_text); ?></p>
                    </div>
                </div>
            </div>

            <div class="row">

                <?php $__currentLoopData = $pricings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pricing): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-3">
                    <div class="single-pricing-box">
                        <h3><?php echo e($pricing->title); ?></h3>
                        <hr>
                        <div class="pricing-list">
                            <ul>
                                <?php $__currentLoopData = $pricing->options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($option != ""): ?>
                                        <li><i class="fa fa-check"></i> <?php echo e($option); ?></li>
                                    <?php else: ?>
                                        <li>&nbsp;</li>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>

                        <h3 class="pricing-count">$<?php echo e($pricing->cost); ?>/Mo</h3>
                        <a href="<?php echo e(url('/services/order')); ?>/<?php echo e($pricing->id); ?>" class="bordered-btn">Order Now</a>
                    </div>
                </div>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>

<section class="projects_area" id="portfolio">
    <div class="container projects">
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <div class="section-title">
                    <h2><?php echo e($languages->portfolio_title); ?></h2>
                    <p><?php echo e($languages->portfolio_text); ?></p>
                </div>
            </div>
            <div class="col-md-12">
                <div class="project_list ">
                    <?php $__currentLoopData = $portfilos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $portfilo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="mix col-md-4 single_project" data-my-order="1">
                        <img src="<?php echo e(url('/assets/images/portfolio')); ?>/<?php echo e($portfilo->image); ?>"/>
                        <div class="project_detail">
                            <div class="project_overlay"></div>
                            <a data-lightbox="example-2" data-title="" href="<?php echo e(url('/assets/images/portfolio')); ?>/<?php echo e($portfilo->image); ?>">
                                <i class="fa fa-search"></i>
                            </a>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- TESTIMONIALS -->
<section class="testimonials">
    <div class="container">
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
                <div class="section-title">
                    <h2><?php echo e($languages->testimonial_title); ?></h2>
                    <p><?php echo e($languages->testimonial_text); ?></p>
                </div>
            </div>
            <div class="col-sm-12">
                <div id="customers-testimonials" class="owl-carousel">
                <?php $__currentLoopData = $testimonials; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $testimonial): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="item">
                        <div class="shadow-effect">
                            <i class="fa fa-quote-right"></i>
                            <div class="item-details">
                                <p class="ctext"><?php echo e($testimonial->review); ?></p>
                                <h5><?php echo e($testimonial->client); ?></h5>
                                <p><?php echo e($testimonial->designation); ?></p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>
    </div>
</section>
<!-- END OF TESTIMONIALS -->

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>