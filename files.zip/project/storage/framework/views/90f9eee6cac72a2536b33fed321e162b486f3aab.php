<?php $__env->startSection('content'); ?>

    <section style="background: url(<?php echo e(url('/')); ?>/assets/images/<?php echo e($settings[0]->background); ?>) no-repeat center center; background-size: cover;">

        <div class="row" style="background-color:rgba(0,0,0,0.7);">
            <div class="container">
                <form action="<?php echo e(action('FrontEndController@search')); ?>" method="post" style="padding: 10% 10% 10% 10%;">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <div class="col-md-3" style="padding-left: 0px;padding-bottom: 15px;">
                            <input id="color" name="city" class="form-control" placeholder="Enter City" list="cities" autocomplete="off" required>
                            <datalist id="cities">
                                <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($city->city); ?>">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </datalist>
                        </div>
                        <div class="col-md-6" style="padding-left: 0px;padding-bottom: 15px;">
                            <input type="text" placeholder="Enter Category" list="categories" name="category" class="form-control" autocomplete="off" required>
                            <datalist id="categories">
                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category->name); ?>">
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </datalist>
                        </div>
                        <div class="col-md-3" style="padding-left: 0px;padding-bottom: 15px;">
                            <button class="btn btn-ocean btn-block" type="submit">Search</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>


    </section>


    <div id="wrapper" class="go-section">
        <div class="row">
            <div class="container">
                <h2 class="text-center"><?php echo e($pagename); ?></h2>
                <hr>
                <div class="gocover"></div>
                <div id="alldocs">
                    <?php $__currentLoopData = $allusers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $alluser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-md-3 col-xs-12 col-sm-6 single">
                            <div class="group">
                                <a href="<?php echo e(url('/')); ?>/profile/<?php echo e($alluser->id); ?>/<?php echo e($alluser->name); ?>">
                                    <img src="<?php echo e(url('/')); ?>/assets/images/profile_photo/<?php echo e($alluser->photo); ?>" class="profile-image" alt="Test Lawyers">
                                    <div class="text-center listing">
                                        <h3 class="no-margin go-bold"><?php echo e($alluser->name); ?></h3>
                                        <p class="no-margin"><?php echo e($alluser->category); ?></p>
                                    </div>
                                </a>
                            </div>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class='col-md-12 margintop'></div>
                </div>

            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('includes.master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>